__turbopack_load_page_chunks__("/Home", [
  "static/chunks/9fc87b79acddb7bf.js",
  "static/chunks/204e2614e99eb52b.js",
  "static/chunks/3b049b51847043db.js",
  "static/chunks/9944a72a16ea643d.js",
  "static/chunks/turbopack-5592618d647e4d7c.js"
])
