__turbopack_load_page_chunks__("/Contact", [
  "static/chunks/9671ca056781b849.js",
  "static/chunks/204e2614e99eb52b.js",
  "static/chunks/3b049b51847043db.js",
  "static/chunks/9944a72a16ea643d.js",
  "static/chunks/turbopack-7cc43ab9e6b32f89.js"
])
