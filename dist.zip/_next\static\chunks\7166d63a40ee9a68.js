__turbopack_load_page_chunks__("/About", [
  "static/chunks/82d980135d3655dd.js",
  "static/chunks/204e2614e99eb52b.js",
  "static/chunks/3b049b51847043db.js",
  "static/chunks/9944a72a16ea643d.js",
  "static/chunks/turbopack-356160d418a83ba2.js"
])
