__turbopack_load_page_chunks__("/Services", [
  "static/chunks/74f32d66ec606438.js",
  "static/chunks/204e2614e99eb52b.js",
  "static/chunks/3b049b51847043db.js",
  "static/chunks/9944a72a16ea643d.js",
  "static/chunks/turbopack-ed9c2a4f9f17aa81.js"
])
