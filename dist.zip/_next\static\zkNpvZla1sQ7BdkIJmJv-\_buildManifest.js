self.__BUILD_MANIFEST = {
  "/About": [
    "static/chunks/7166d63a40ee9a68.js"
  ],
  "/Contact": [
    "static/chunks/1e6076aa40ced5d7.js"
  ],
  "/Home": [
    "static/chunks/433f35985bede1ec.js"
  ],
  "/Services": [
    "static/chunks/da95f6368c98c215.js"
  ],
  "/_error": [
    "static/chunks/9eab2353a63bed66.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/About",
    "/Contact",
    "/Home",
    "/Services",
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()